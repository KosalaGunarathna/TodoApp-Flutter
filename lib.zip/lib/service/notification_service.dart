import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

import '../model/todo.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
  const AndroidInitializationSettings androidSettings =
      AndroidInitializationSettings('@mipmap/ic_launcher');

  const InitializationSettings settings =
      InitializationSettings(android: androidSettings);

  await plugin.initialize(settings);

  // 🔥 Ask notification permission (Android 13+)
  await plugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.requestNotificationsPermission();

  // 🔥 Ask exact alarm permission
  await plugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.requestExactAlarmsPermission();
}

  static Future<void> scheduleTodo(ToDo todo) async {
    if (todo.date == null || todo.time == null) {
      print("Date or Time null");
      return;
    }

    final scheduledDate = DateTime(
      todo.date!.year,
      todo.date!.month,
      todo.date!.day,
      todo.time!.hour,
      todo.time!.minute,
    );

    // 🔥 1 hour before
    final reminderTime =
        scheduledDate.subtract(const Duration(hours: 1));

    print("Reminder Time: $reminderTime");

    // Prevent past notification
    if (reminderTime.isBefore(DateTime.now())) {
      print("Reminder time already passed");
      return;
    }

    await plugin.zonedSchedule(
      todo.id.hashCode,
      'Todo Reminder',
      todo.todoText ?? '',
      tz.TZDateTime.from(reminderTime, tz.local),

      const NotificationDetails(
        android: AndroidNotificationDetails(
          'todo_channel',
          'Todo Notifications',
          channelDescription: 'Todo reminder notification',
          importance: Importance.max,
          priority: Priority.high,
        ),
      ),

      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,

      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );

    print("Notification Scheduled");
  }
}